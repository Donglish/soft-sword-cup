#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <jsoncpp/json/json.h> 
#include <sstream>
#include "json.hpp"
#include "search.h"
#include "match.h"
#include "readtxt.h"
#include "preprocessing.h"
#include <sys/types.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "customer.h"
using namespace std;


int main()
{
	//pricefunc();      
	//airfunc();
    //seatfunc();
    //tablefunc();  
    //combine_airandseat();

    int listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd == -1) {
        //cout << " create listen socket error " << endl;
        return -1;
    }

    struct sockaddr_in bindaddr;
    bindaddr.sin_family = AF_INET;
    bindaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    bindaddr.sin_port = htons(8999);
    if (bind(listenfd, (struct sockaddr *)& bindaddr, sizeof(bindaddr)) == -1) {
            //cout << "bind listen socket error" << endl;
            return -1;
        }
    if (listen(listenfd, SOMAXCONN) == -1) {
        cout << "listen error" << endl;
        return -1;
    }

    while (true) {

        struct sockaddr_in clientaddr;
        socklen_t clientaddrlen = sizeof(clientaddr);
        int clientfd = accept(listenfd, (struct sockaddr *)& clientaddr, &clientaddrlen);
        if (clientfd != -1) {
           
            int ret = recv(clientfd, recvBuf, MAXBUF, 0);         
            close(clientfd);
        }
    }

    close(listenfd);


    dealtable();
    Form_Part();
    
    Search5(crequest.travelnum);
    /*
    cout<<"input"<<endl;
    //while(1){
    cin>>crequest.custnum>>crequest.travelnum>>crequest.ansnum;
    request_ans=crequest.ansnum;
    traveller=stoi(crequest.custnum);
    for(int i=0;i<crequest.travelnum;i++){
        pair<string,string> tmpcity;
        cin>>tmpcity.first>>tmpcity.second;
        string tmpdaytime;
		cin>>tmpdaytime;
		crequest.daytime.push_back(tmpdaytime); 
        crequest.fromto_city.push_back(tmpcity);
    }
    int agencynum;cin>>agencynum;
    for(int i=0;i<agencynum;i++){
        string tmpstr;
        cin>>tmpstr;
        request_agency.push_back(tmpstr);
    }
    
    Form_Part();
    
    
	
    Search5(crequest.travelnum);
    //cout<<"--------------------------"<<endl;
	//} 
    
    
    //cout<<endl<<ALL_PATH[0].size()<<endl;
    */
}
 








